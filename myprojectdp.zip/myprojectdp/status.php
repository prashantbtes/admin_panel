<!DOCTYPE html>
<html>
<head>
	<title>Status Delivery Person </title>
 <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta name="description" content="">
   <meta name="author" content="">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
   	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <style type="text/css"></style>
</head>
<body>
<center>
  <h2> Status Of delivery Boy </h2></center>
 <table class="table table-bordered">
 	<thead>
 		<tr>
 			<th scope="col">Id</th>
 			<th scope="col">Name</th>
 			<th scope="col">Mobile</th>
 			<th scope="col">Email</th>
 			<th scope="col">City</th>
 			<th scope="col">Availability</th>

 		</tr>
<tbody>
	<tr>
		<td>1</td>
		<td>Pk</td>
		<td>987654321</td>
		<td>email@gmail.com</td>
		<td>mohali</td>
		<td> <select>Status</select>
		<option value="online">Available </option>
		<option value="offline">Not Available </option>
	    </td>

      
	</tr>


</tbody>

 




</body>
</html>